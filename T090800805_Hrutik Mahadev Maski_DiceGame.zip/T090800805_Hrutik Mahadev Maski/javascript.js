function playGame() {
    // Player 1 
    var randomNum1 = Math.floor(Math.random() * 6) + 1;
    var randomImageSource1 = "IMGs/dice_roll_" + randomNum1 + ".png";
    var image1 = document.querySelectorAll("img")[0];
    image1.setAttribute("src", randomImageSource1);
  
    // Player 2 
    var randomNum2 = Math.floor(Math.random() * 6) + 1;
    var randomImageSource2 = "IMGs/dice_roll_" + randomNum2 + ".png";
    var image2 = document.querySelectorAll("img")[1];
    image2.setAttribute("src", randomImageSource2);
  
    // Player 3 
    var randomNum3 = Math.floor(Math.random() * 6) + 1;
    var randomImageSource3 = "IMGs/dice_roll_" + randomNum3 + ".png";
    var image3 = document.querySelectorAll("img")[2];
    image3.setAttribute("src", randomImageSource3);
  
    // Player 4 
    var randomNum4 = Math.floor(Math.random() * 6) + 1;
    var randomImageSource4 = "IMGs/dice_roll_" + randomNum4 + ".png";
    var image4 = document.querySelectorAll("img")[3];
    image4.setAttribute("src", randomImageSource4);
  
    // Main Logic of Dice Game
    var winner = "It's a Draw!";
    
    // Finding the maximum score and checking for a winner
    var maxScore = Math.max(randomNum1, randomNum2, randomNum3, randomNum4);
    
    var winners = [];
    if (randomNum1 === maxScore) winners.push("Player 1");
    if (randomNum2 === maxScore) winners.push("Player 2");
    if (randomNum3 === maxScore) winners.push("Player 3");
    if (randomNum4 === maxScore) winners.push("Player 4");
    
    if (winners.length === 1) {
      winner = winners[0] + " Wins!";
    } else if (winners.length > 1) {
      winner = winners.join(" and ") + " Win!";
    }
    
    document.querySelector("h1").innerHTML = winner;
  }
  
  // Start the game when the page loads
  window.onload = playGame;
  